﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questão3_ED
{
    class NoLista
    {
        // Attributes
        private NoLista anterior;
        private NoLista prox;
        private double info;

        // Methods
        public NoLista()
        {
            anterior = null;
            prox = null;
            info = 0.0;
        }

        public NoLista(double info)
        {
            anterior = null;
            prox = null;
            this.info = info;
        }

        // Getters & Setters
        public NoLista Anterior{
            get => anterior;
            set => anterior = value;}
        public NoLista Prox{
            get => prox;
            set => prox = value;}

        public double Info{
            get => info;
            set => info = value;}
    }
}
