﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace Questão3_ED
{
    class Program
    {
        static void Main(string[] args)
        {
            Lista listaDouble = new Lista();
            bool aux = true;

            while (aux)
            {
                Console.WriteLine("Escolha uma opção do menu (COLOQUE O DOUBLE COM VÍRGULA, ex: 2,1):\n");
                Console.WriteLine(" [1] - Iserir um double");
                Console.WriteLine(" [2] - Remover um double");
                Console.WriteLine(" [3] - Mostrar todos os doubles");
                Console.WriteLine(" [4] - Sair");

                string option = Console.ReadLine();

               
                switch (option)
                {
                    case "1":
                        Console.Write("Digite o double:\n");
                        double elemento = Convert.ToDouble(Console.ReadLine());
                        // INSIRA O ELEMENTO NA LISTA
                        listaDouble.Insere(elemento);
                        Console.Clear();
                        break;

                    case "2":
                        Console.WriteLine("Que double deseja remover?");
                        double numero = Convert.ToDouble(Console.ReadLine());
                        listaDouble.Remove(numero);
                        Console.WriteLine("Removido");
                        Console.ReadLine();
                        // REMOVA O ELEMENTO DA LISTA
                        Console.Clear();
                        break;

                    case "3":
                        Console.Write("Resultado :\n");
                        listaDouble.PrintItems();        // IMPRIMA A LISTA
                        Console.ReadLine();
                        Console.Clear();
                        break;

                    case "4":
                        aux = false;
                        Console.Clear();
                        break;

                    default:
                        Console.Write("Favor selecionar uma das opções mostradas no menu\n");
                        break;
                }
                



            }

        }
    }
}