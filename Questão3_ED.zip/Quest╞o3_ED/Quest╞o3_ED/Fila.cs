﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questão3_ED
{
    class Lista
    {
        // Attributes
        private NoLista primeiro;
        private NoLista ultimo;

        // Methods
        public Lista()
        {
            primeiro = null;
            ultimo = null;
        }

        public bool taVazio()
        {
            if (primeiro == null && ultimo == null) return true;
            return false;
        }

        public void InsereInicio(double info)
        {
            NoLista novoNo = new NoLista(info);

            if (taVazio())
            {
                primeiro = novoNo;
                ultimo = novoNo;
            }
            else
            {
                novoNo.Prox = primeiro;
                primeiro.Anterior = novoNo;
                primeiro = novoNo;
            }
        }

        public void Insere(double dado)// Insere de maneira crescente
        {
            NoLista novoNo = new NoLista(dado);

            if (primeiro == null)
            {
                primeiro = novoNo;
            }
            else if (dado < primeiro.Info)
            {
                novoNo.Prox = primeiro;
                primeiro = novoNo;
            }
            else
            {
                NoLista atual = primeiro;
                while (atual.Prox != null && dado > atual.Prox.Info)
                {
                    atual = atual.Prox;
                }
                novoNo.Prox = atual.Prox;
                atual.Prox = novoNo;
            }
        }

        public void InsereFim(double info)
        {
            NoLista novoNo = new NoLista(info);

            if (taVazio())
            {
                primeiro = novoNo;
                ultimo = novoNo;
            }
            else
            {
                novoNo.Anterior = ultimo;
                ultimo.Prox = novoNo;
                ultimo = novoNo;
            }
        }

        public double Remove(double info)
        {
            NoLista aux = primeiro;

            while (aux != null)
            {
                if (aux.Info == info)
                {
                    if (aux.Anterior == null & aux.Prox == null)  // Elemento único
                    {
                        primeiro = null;
                        ultimo = null;
                    }
                    else if (aux == primeiro)                        // Elemento inicial
                    {
                        primeiro = aux.Prox;
                        aux.Prox.Anterior = null;
                    }
                    else if (aux == ultimo)                         // Elemento final
                    {
                        ultimo = aux.Anterior;
                        aux.Anterior.Prox = null;
                    }
                    else                                          // Elemento intermediário
                    {
                        aux.Anterior.Prox = aux.Prox;
                        aux.Prox.Anterior = aux.Anterior;
                    }

                    return aux.Info;
                }

                aux = aux.Prox;
            }

            return UInt16.MaxValue;
        }

        public void Clear()
        {
            primeiro = null;
            ultimo = null;
        }

        public void PrintItems()
        {
            if (taVazio())
                Console.WriteLine("A lista está vazia...");

            NoLista temp = primeiro;
            while (temp != null)
            {
                Console.Write(temp.Info.ToString("0.0", CultureInfo.InvariantCulture) + " ");
                temp = temp.Prox;
            }
        }

        internal NoLista Primeiro { get => primeiro; set => primeiro = value; }
        internal NoLista Ultimo { get => ultimo; set => ultimo = value; }
    }
}
