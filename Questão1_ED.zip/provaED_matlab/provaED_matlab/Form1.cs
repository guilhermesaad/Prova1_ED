namespace provaED_matlab
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonAction_Click(object sender, EventArgs e)
        {
            string entrada = textBoxEntrada.Text;
            int tamanho = entrada.Length;


            Pilha pilhaParenteses = new Pilha();
            Pilha pilhaColchetes = new Pilha();
            Pilha pilhaChaves = new Pilha();

            for (int i = 0; i < tamanho; i++)
            {
                if (entrada[i] == '(')
                    pilhaParenteses.insere('(');
                else if (entrada[i] == '[')
                    pilhaColchetes.insere('[');
                else if (entrada[i] == '{')
                    pilhaChaves.insere('{');

                if (entrada[i] == ')')
                {
                    if (pilhaParenteses.estaVazia())
                    {
                        pilhaParenteses.insere('.');
                        break;
                    }
                    if (pilhaParenteses.top() == '(')
                        pilhaParenteses.remove();


                }

                else if (entrada[i] == ']')
                {
                    if (pilhaColchetes.estaVazia())
                    {
                        pilhaColchetes.insere(':');
                        break;
                    }
                    if (pilhaColchetes.top() == '[')
                        pilhaColchetes.remove();

                }

                else if (entrada[i] == '}')
                {
                    if (pilhaChaves.estaVazia())
                    {
                        pilhaChaves.insere(';');
                        break;
                    }
                    else if (pilhaChaves.top() == '{')
                        pilhaChaves.remove();
                }
            }

            if (pilhaChaves.estaVazia() &&
                pilhaColchetes.estaVazia() && pilhaParenteses.estaVazia())
            {
                textBoxSaida.Text = "Nenhum erro encontrado";
            }
            else
            {
                if (!pilhaChaves.estaVazia() && pilhaChaves.top() == ';')
                    textBoxSaida.Text = "Erro: '}' desnecess�rio";
                else if(!pilhaChaves.estaVazia())
                    textBoxSaida.Text = "Erro: '}' esperado";

                if (!pilhaColchetes.estaVazia() && pilhaColchetes.top() == ':')
                    textBoxSaida.Text = "Erro: ']' desnecess�rio";
                else if (!pilhaColchetes.estaVazia())
                    textBoxSaida.Text = "Erro: ']' esperado";

                if (!pilhaParenteses.estaVazia() && pilhaParenteses.top() == '.')
                    textBoxSaida.Text = "Erro: ')' desnecess�rio";
                else if (!pilhaParenteses.estaVazia())
                    textBoxSaida.Text = "Erro: ')' esperado";

            }


        }
    }
}