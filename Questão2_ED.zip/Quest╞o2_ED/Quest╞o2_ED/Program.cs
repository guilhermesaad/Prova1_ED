﻿using Questão2_ED;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questão2_ED
{
    class Program
    {
        static void Main(string[] args)
        {

            Pilha pilha = new Pilha();
            bool aux = true;

            while (aux)
            {
                Console.WriteLine("Escolha uma opção do menu :\n");
                Console.WriteLine(" [1] - Inserir um carro no estacionamento (insira o carro digitando uma letra)");
                Console.WriteLine(" [2] - Remover um carro do estacionamento");
                Console.WriteLine(" [3] - Mostrar todos os carros estacionados");
                Console.WriteLine(" [4] - Sair");
                
                string option = Console.ReadLine();

                if (pilha.cheia() && option == "1")
                {
                    Console.Write("Estacionamento lotado, não é possível colocar mais carros\n");
                }
                else 
                {
                    switch (option)
                    {
                        case "1":
                            Console.Write("Digite a letra que representa o carro:\n");
                            char elemento = Convert.ToChar(Console.ReadLine());
                            // INSIRA O ELEMENTO NA PILHA
                            pilha.insere(elemento);
                            Console.Clear();
                            break;

                        case "2":
                            Console.WriteLine("Que carro deseja remover?");
                            char carro = Convert.ToChar(Console.ReadLine());
                            pilha.removeMeio(carro);
                            Console.WriteLine("Removido");
                            Console.ReadLine();
                            // REMOVA O ELEMENTO DA PILHA
                            Console.Clear();
                            break;

                        case "3":
                            Console.Write("Estacionamento :\n");
                            pilha.imprime();        // IMPRIMA A PILHA
                            Console.ReadLine();
                            Console.Clear();
                            break;

                        case "4":
                            aux = false;
                            Console.Clear();
                            break;

                        default:
                            Console.Write("Favor selecionar uma das opções mostradas no menu\n");
                            break;
                    }
                }
                


            }

        }
    }
}
